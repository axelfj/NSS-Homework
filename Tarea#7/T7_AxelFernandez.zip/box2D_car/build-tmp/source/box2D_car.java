import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import shiffman.box2d.*; 
import org.jbox2d.collision.shapes.*; 
import org.jbox2d.common.*; 
import org.jbox2d.dynamics.*; 
import java.util.ListIterator; 
import org.jbox2d.dynamics.joints.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class box2D_car extends PApplet {








Box2DProcessing box2d;
ArrayList<Car> cars;
Surface surface;
Car car;

public void setup(){
    

  displayRect();

  box2dInit();
  surface = new Surface();
  cars = new ArrayList();
  ArrayList<Vec2> carPoints = new ArrayList();
  carPoints.add(new Vec2(0,-20));
}

public void displayRect(){
  noStroke();
  rectMode(CORNER);
  fill(0,55);
  rect(0,0,width,height);
}

public void box2dInit(){
  box2d = new Box2DProcessing(this);
  box2d.createWorld();
}

public void draw(){
  displayRect();
  surface.display();
  box2d.step();
  for (Car a : cars) a.display();
  
  ListIterator<Car> it = cars.listIterator();
  while (it.hasNext()){
    Car c = it.next();
    if (c.done()) it.remove();
  }
}

public void mousePressed(){
  Car c = new Car(mouseX,mouseY);
  cars.add(c);
}
abstract class Agent{
  Body body;
  public abstract void killBody();
  public abstract boolean done();
  public abstract void display();
}
class Car{
  CircleAgent wheel1, wheel2;
  PolygonAgent base;
  Joint joint1, joint2;
  
  Car(float x, float y){
    ArrayList<Vec2> basePoints = new ArrayList();
    basePoints.add(new Vec2(-25,-3));
    basePoints.add(new Vec2(25,-3));
    basePoints.add(new Vec2(25,3));
    basePoints.add(new Vec2(-25,3));
    base = new PolygonAgent(x, y, basePoints, BodyType.DYNAMIC);
    
    wheel1 = new CircleAgent(x-25,y,15);
    wheel2 = new CircleAgent(x+25,y,15);
    
    RevoluteJointDef rjd1 = new RevoluteJointDef();
    RevoluteJointDef rjd2 = new RevoluteJointDef();
    rjd1.initialize(base.body,wheel1.body,wheel1.body.getTransform().p);
    rjd2.initialize(base.body,wheel2.body,wheel2.body.getTransform().p);
    
    float torque = random(-8000,-6000);
    float speed = random(5000,10000);

    rjd1.motorSpeed = -PI * speed;
    rjd1.maxMotorTorque = torque;
    rjd1.enableMotor = true;
    
    rjd2.motorSpeed = -PI * speed;
    rjd2.maxMotorTorque = torque;
    rjd2.enableMotor = true;
    
    joint1 = box2d.createJoint(rjd1);
    joint2 = box2d.createJoint(rjd2);
  }
  
  public void display(){
    base.display();
    wheel1.display();
    wheel2.display();
  }  
  
  public boolean done(){
    if (wheel1.done() || wheel2.done() || base.done()) return true;
    else return false;
  }
}
class CircleAgent extends Agent{
  float r;
  int c;

  CircleAgent(float x, float y, float r){
    this.r = r;

    colorMode(HSB);
    c = color(frameCount%255,255,255);
    colorMode(RGB);

    BodyDef bodyDef = new BodyDef();
    
    bodyDef.position = box2d.coordPixelsToWorld(x,y);
    bodyDef.type = BodyType.DYNAMIC;
    body = box2d.createBody(bodyDef);
    
    CircleShape circleShape = new CircleShape();
    circleShape.setRadius(box2d.scalarPixelsToWorld(r));
    
    FixtureDef fixtureDef = new FixtureDef();
    fixtureDef.shape = circleShape;
    fixtureDef.density = 100;
    fixtureDef.friction = 10;
    fixtureDef.restitution = 0;
    
    body.createFixture(fixtureDef);
  }
  
  public void killBody(){
    box2d.destroyBody(body);
  }
  
  public boolean done(){
    Vec2 pos = box2d.getBodyPixelCoord(body);
    if (pos.x < -r*2 || pos.x > width+r*2){
      killBody(); 
      return true;
    }
    else if (pos.y < -r*2 || pos.y > height+r*2){ 
      killBody(); 
      return true;
    }
    return false;
  }
  
  public void display(){
    Vec2 pos = box2d.getBodyPixelCoord(body);
    float a = body.getAngle();
    pushMatrix();
    translate(pos.x,pos.y);
    rotate(-a);
    
    fill(c);
    
    stroke(255);
    strokeWeight(1);
    ellipse(0,0,r*2,r*2);
    line(-r,0,r,0);
    line(0,-r,0,r);
    popMatrix();
  }
}
class PolygonAgent extends Agent{
  ArrayList<Vec2> vertex; // pixeles
  int c;
  
  
  PolygonAgent(float x, float y, ArrayList<Vec2> vertex){
    this(x,y,vertex,BodyType.DYNAMIC);
  }
  
  PolygonAgent(float x, float y, ArrayList<Vec2> vertex, BodyType type){
    this.vertex = vertex;    
    colorMode(HSB);
    c = color(frameCount % 255, 255, 255);
    colorMode(RGB);
    
    BodyDef bodyDef = new BodyDef();
    bodyDef.position = box2d.coordPixelsToWorld(x,y);
    bodyDef.type = type;
    body = box2d.createBody(bodyDef);
    
    PolygonShape polygonShape = new PolygonShape();
    Vec2[] worldVertex = new Vec2[vertex.size()];
    for (int i = 0; i < vertex.size(); i++){
      worldVertex[i] = box2d.vectorPixelsToWorld(vertex.get(i));
    }
    polygonShape.set(worldVertex,vertex.size());
    
    FixtureDef fixtureDef = new FixtureDef();
    fixtureDef.shape = polygonShape;
    fixtureDef.density = 1;
    fixtureDef.restitution = 0.2f;
    fixtureDef.friction = 1;
    
    body.createFixture(fixtureDef);
  }
  
  public void display(){
    Vec2 pos = box2d.getBodyPixelCoord(body);
    float a = body.getAngle();
    pushMatrix();
    translate(pos.x,pos.y);
    rotate(-a);
    stroke(255);
    strokeWeight(2);
    fill(c);
    beginShape();
    for (Vec2 v: vertex) vertex(v.x,v.y);
    endShape(CLOSE);
    popMatrix();
  }
  
  public boolean done(){
    Vec2 pos = box2d.getBodyPixelCoord(body);
    if (pos.x < -50 || pos.x > width+50) {
      killBody();
      return true;
    }
    if (pos.y < -50 || pos.y > height+50) {
      killBody();
      return true;
    }
    return false;
  }
  
  public void killBody(){
    box2d.destroyBody(body);
  }
}
class Surface{
  ArrayList<Vec2> points;
  float offset = random(100);
  float xOff = 0.01f;

  Surface(){
    this.points = new ArrayList();
    
    BodyDef bodyDef = new BodyDef();
    bodyDef.position = new Vec2(0,0);
    Body body;
    body = box2d.createBody(bodyDef);
    
    for (float x = 0; x < width; x += 6){
      float y = map(noise(offset),0,1,height*2/3,height);
      Vec2 v = new Vec2(x,y);
      points.add(v);
      offset+=xOff;
    }
    
    Vec2[] worldPoints = new Vec2[points.size()];
    for (int i = 0; i < points.size(); i++) worldPoints[i] = box2d.coordPixelsToWorld(points.get(i));
    ChainShape chainShape = new ChainShape();
    chainShape.createChain(worldPoints, worldPoints.length);
    body.createFixture(chainShape, 1);
  }
  
  public void display(){
    stroke(255);
    strokeWeight(10);
    for (int i = 0; i < points.size()-1; i++){
      Vec2 v1 = points.get(i);
      Vec2 v2 = points.get(i+1);
      line(v1.x,v2.y,v2.x,height);
    }
  }
}
  public void settings() {  fullScreen(); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "box2D_car" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
