class AgentSystem implements IAgent{
  LinkedList<Agent> agents;
  LinkedList<Spring> springs;
  PVector pos;
  float size, rythm;
  float fric = -0.01;
  float lifeDecrease = 1;
  float k = 0.01;
  float restLen = 10;
  
  AgentSystem(float x, float y, float lifeDecrease){
    this(x,y);
    this.lifeDecrease = lifeDecrease;
  }
  
  AgentSystem(float x, float y){
    agents = new LinkedList();
    springs = new LinkedList();
    pos = new PVector(x,y);
  }
  
  void update(){
    for (Agent a: agents)
      a.update();
     
    for (Spring s: springs)
      s.update();
    
    ListIterator<Agent> it = agents.listIterator();
    while (it.hasNext()){
      Agent a = it.next();
      if (a.isDead()){
        it.remove();
      }  
    }
    ListIterator<Spring> it2 = springs.listIterator();
    while(it2.hasNext()){
      Spring s = it2.next();
      if (s.a1.isDead() || s.a2.isDead()){
        it2.remove();
      }
    }
  }
  
  void display(){
    for (Agent a: agents){
      a.display();
      PVector fr= a.vel.copy();
      fr.normalize();
      fr.mult(fric);
      a.addForce(fr);
    }

    for (Spring s: springs)
      s.display();
  }
  
  void addForce(PVector f){
    for (Agent a: agents)
      a.addForce(f);
  }
    
  void addAgent(){
    Agent a1 = new Agent(pos.x,pos.y,random(5,25), lifeDecrease);
    Agent a2 = new Agent(pos.x,pos.y,random(5,25), lifeDecrease);
    agents.add(a1);
    agents.add(a2);
    springs.add(new Spring(a1,a2,k,restLen));
  }
  
  void addAgent(Agent a){
    agents.add(a);
  }

  void setLifeDecrease(float lifeDecrease){
    this.lifeDecrease = lifeDecrease;
    for (Agent a: agents)
      a.lifeDecrease = lifeDecrease;
  }

  void setK(float k){
    this.k = k;
    for (Spring s: springs)
      s.k = k;
  }

  void setRestLen(float restLen){
    this.restLen = restLen;
    for (Spring s: springs)
      s.restLen = restLen;
  }

  void setFric(float fric){
    this.fric = fric;
  }
}
