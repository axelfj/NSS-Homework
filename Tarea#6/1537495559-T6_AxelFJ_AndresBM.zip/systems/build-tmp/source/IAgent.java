interface IAgent{
  void update();
  void display();
}
