class Agent implements IAgent{
  PVector pos, vel, acc;
  color c;
  float lifespan, lifeDecrease, size;
  
  Agent(float x, float y, float size, float lifeDecrease){
    this(x,y);
    this.size = size;
    this.lifeDecrease = lifeDecrease;
  }

  Agent(float x, float y){
    pos = new PVector(x,y);
    vel = PVector.random2D();
    vel.setMag(map(randomGaussian(),-1,1,0,1));
    acc = new PVector(0,0);
    c = color(#B46F2E);
    lifespan = 255;
    //lifeDecrease = 1;
    size = 10;
  }

  void update(){
    /*c = color(
      map(pos.x,0,width,0,255),
      map(pos.y,0,height,0,255),
      128);*/
    colorMode(HSB);
    c = color(frameCount % 255, 255, 255);
    colorMode(RGB);
    vel.add(acc);
    pos.add(vel);
    acc.mult(0);
    lifespan -= lifeDecrease;
  }
  
  void display(){
    noStroke();
    fill(c,lifespan);
    ellipse(pos.x,pos.y,size,size);
  }
  
  void addForce(PVector f){
    acc.add(f);
  }
  
  boolean isDead(){
    if (lifespan <= 0) 
      return true; 
    return false;
  }

  void setLifeDecrease(float lifeDecrease){
    this.lifeDecrease = lifeDecrease;
  }
}
